module BKUPJ9_DB2_Gyak3 {
	requires java.sql;
}