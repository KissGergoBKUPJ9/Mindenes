module BKUPJ9_DB2 {
	requires java.sql;
	requires ojdbc6;
}