module JavaProgGyak2 {
}