package gyak3;

public class EmpProg {
	private static Emp[] emp = new Emp[4];
	public static void main(String[] args) {
		emp[0] = new Emp("Kis B�la", 250000);
		emp[1] = new Emp("J� Zoli", 325000);
		emp[2] = new Emp("S� B�la Peti", 99000);
		emp[3] = new Emp("B�la Tomi",420000);
		
		Emp.print(emp);
		Emp.sortNev(emp);
		Emp.sortFiz(emp);
		Emp.search(emp, "Kis B�la");
		Emp.searchFirstName(emp, "B�la");
	}

}
