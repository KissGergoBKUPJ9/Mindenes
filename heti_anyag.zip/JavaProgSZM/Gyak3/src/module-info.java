module JavaProgGyak3 {
}